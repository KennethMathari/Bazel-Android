This is a barebones Android app for the [Bazel Android tutorial](https://docs.bazel.build/versions/master/tutorial/android-app.html).
