package com.example.bazel;

import static org.junit.jupiter.api.Assertions.*;

class MainActivityTest {

}