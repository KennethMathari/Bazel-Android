package com.example.bazel;

/**
 * A tiny Greeter library for the Bazel Android "Hello, World" app.
 */
public class Greeter {
  public String sayHello() {
    return "Hello Bazel! \uD83D\uDC4B\uD83C\uDF31"; // Unicode for 👋🌱
  }
}
